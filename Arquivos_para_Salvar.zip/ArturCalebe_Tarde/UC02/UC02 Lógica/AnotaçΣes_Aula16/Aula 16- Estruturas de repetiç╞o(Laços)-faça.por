programa {
  funcao inicio() {
    inteiro senhaSuperSegura = 1234
    inteiro senhaDigitada, tentativas, maxTentativas

    maxTentativas = 3
    tentativas = 0
    faca {
      escreva("Digite a senha de acesso(4 digitos): ")
      leia(senhaDigitada)
      tentativas = tentativas + 1
      se(senhaDigitada != senhaSuperSegura) {
        escreva("Senha incorreta. Tentativas ",tentativas," de ",maxTentativas, "\n")
      }
    }
    enquanto(senhaDigitada != senhaSuperSegura e tentativas < maxTentativas)

    se(senhaDigitada == senhaSuperSegura) {
      escreva("Acesso Liberado", "\n")
    } senao {
      escreva("Conta foi bloqueada após ", maxTentativas, " tentativas! ", "\n")
    }

  }
}
