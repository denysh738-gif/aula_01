programa {
  funcao inicio() {
    inteiro fileiras, mesasPorFileiras, fil, mesa

    escreva("Informe o número de fileiras: ")
    leia(fileiras)

    escreva("Informe a quantidade de mesas por fileiras: ")
    leia(mesasPorFileiras)

    para(fil = 1; fil <= fileiras; fil++) {
      para(mesa = 1; mesa <= mesasPorFileiras; mesa++) {
        se(mesa == mesasPorFileiras) {
        escreva("(J)")
        
        } senao {
        escreva("(M)")
        }

     }
      escreva("\n")
    }

    escreva("\n")

    /*
    (M) (M) (M) (J)
    (M) (M) (M) (J)
    (M) (M) (M) (J)
    (M) (M) (M) (J)
    
    */



  }
}
