programa {
  funcao inicio() {
    inteiro n, i, codigoBuscado
    logico encontrado

    escreva("Quantos produtos no cadastro (max 20)")
    leia(n)
    inteiro codigos[20]
    real precos[20]
    para(i = 0; i < n; i++) {
      escreva("código do produto ", i + 1, ": ")
      leia(codigos[i])
      escreva("Preço: R$ ")
      leia(precos[i])
    }
    escreva("Digite o código do produto para buscar: ")
    leia(codigoBuscado)
    encontrado = falso
      para(i = 0; i < n; i++) {
       se(codigos[i] == codigoBuscado) {
         encontrado = verdadeiro
       }
    }
    se(encontrado) {
      escreva("Produto encontrado! ")
    }
    senao {
      escreva("Produto não encontrado! ")
    }
  }
}
