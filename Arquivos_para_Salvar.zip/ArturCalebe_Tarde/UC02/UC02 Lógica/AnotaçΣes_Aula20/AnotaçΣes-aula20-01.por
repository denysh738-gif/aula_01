programa {
  funcao inicio() {
    inteiro grade[4][3]
    grade[1][2] = 45
    
    para(inteiro linha = 0; linha < 4; linha++) {
        para(inteiro coluna = 0; coluna < 3; coluna++) {
        escreva("Linha ",linha," da matriz e seu valor: ", grade[linha][coluna], "\n")
      }
    }

  }
}
