programa {
  funcao inicio() {
    inteiro funcionarios, dias, linha, coluna, linhaAchado, colunaAchado
    logico encontrado
    funcionarios = 3
    dias = 5
    inteiro ponto[3][5]
    cadeia nomeFuncionario[3]
    nomeFuncionario[0] = "Eduarda"
    nomeFuncionario[1] = "Alberto"
    nomeFuncionario[2] = "Victória"

    para(linha = 0; linha < funcionarios; linha++) {
      escreva(nomeFuncionario[linha], ": ", "\n")
      para(coluna = 0; coluna < dias; coluna++) {
        escreva("Dia ", coluna + 1, ": ")
        leia(ponto[linha][coluna])
      }
    }
    encontrado = falso
    linhaAchado = -1
    colunaAchado = -1
    para(linha = 0; linha < funcionarios; linha++) {
      se(nao encontrado) {
        para(coluna = 0; coluna < dias; coluna++) {
          se(nao encontrado e ponto[linha][coluna] == 0) {
            encontrado = verdadeiro
            linhaAchado = linha
            colunaAchado = coluna
          }
        }
      }
    }

    se(encontrado) {
      escreva("Primeira falta: ", nomeFuncionario[linhaAchado], "\n")
      escreva("Dia ", colunaAchado + 1, "\n")
    } senao {
      escreva("Nenhuma falta encontrada! \n")
    }
















  }
}
