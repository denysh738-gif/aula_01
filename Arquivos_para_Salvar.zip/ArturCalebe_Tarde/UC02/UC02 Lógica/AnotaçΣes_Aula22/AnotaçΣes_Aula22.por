programa {
 
  inclua biblioteca Objetos
  inclua biblioteca Util --> util
 
  funcao inicio() {
    inteiro alunos[3]
    cadeia nome
    inteiro idade
    real media
     
    para(inteiro indice = 0; indice < util.numero_elementos(alunos); indice++) {
       alunos[indice] = Objetos.criar_objeto()
       escreva("Nome do ", indice + 1, "º aluno: ")
       leia(nome)
       escreva("Idade: ")
       leia(idade)
       escreva("Média: ")
       leia(media)

       Objetos.atribuir_propriedade(alunos[indice], "Nome: ", nome)
       Objetos.atribuir_propriedade(alunos[indice], "Idade: ", idade)
       Objetos.atribuir_propriedade(alunos[indice], "Média: ", media)
    }

    escreva("-- ALUNOS CADASTRADOS --", "\n")
    para(inteiro indice = 0; indice < util.numero_elementos(alunos); indice++) {
      nome = Objetos.obter_propriedade_tipo_cadeia(alunos[indice], "Nome")
      idade = Objetos.obter_propriedade_tipo_inteiro(alunos[indice], "Idade")
      media = Objetos.obter_propriedade_tipo_real(alunos[indice], "Média")
      escreva("Aluno: ", nome, " | Idade: ", idade, " | Média: ", media, "\n")
    }
  }
}
