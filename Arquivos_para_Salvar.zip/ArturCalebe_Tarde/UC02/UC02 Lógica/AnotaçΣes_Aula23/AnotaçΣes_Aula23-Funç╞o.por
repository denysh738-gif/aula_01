programa {
  funcao real calcularMediaDeDuasNotas(real numero1, real numero2) {
    real media
    media = (numero1 + numero2) / 2
    retorne media
  }
  funcao vazio quebraDeLinha() {
    escreva("\n")
  }
  funcao vazio boletimEscolar(cadeia nome, real nota1, real nota2) {
    real media = calcularMediaDeDuasNotas(nota1, nota2)
    se(media >= 6.0) {
      escreva("Aluno ", nome, " foi aprovado com a média ", media)
    } senao {
      escreva("Aluno ", nome, " foi reprovado com a média ", media)
    }
  }
  funcao inicio() {
    cadeia nome 
    real nota1, nota2
    
    escreva("Nome do aluno: ", "\n")
    leia(nome)
    
    escreva("Informe a primeira nota: ", "\n")  
    leia(nota1)
    
    escreva("Informe a segunda nota: ", "\n")
    leia(nota2)
    
    boletimEscolar(nome, nota1, nota2) 
  }
}
