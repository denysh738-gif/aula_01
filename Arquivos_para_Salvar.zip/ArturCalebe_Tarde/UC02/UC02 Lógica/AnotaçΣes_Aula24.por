programa {
  funcao real calcularPrecoCopo(inteiro tamanho, inteiro adicionais) {
    real base
    se(tamanho == 300) {
      base = 12.0 
    } senao {
      se(tamanho == 500) {
        base = 18.0
      } senao {
        base = 24.0
      }
    } 
    retorne base + adicionais * 3.0
  }
  funcao real aplicarDesconto(real valor, real percentual) {
    retorne valor - (valor * percentual / 100.0)
  }
  funcao logico temFreteGratis(real subtotal) {
    retorne subtotal >= 35.0
  } 
  funcao real calcularFrete(real distacia) {
    se(distacia <= 3) {
      retorne 5.0 
    } 
    se(distacia <= 8.0) {
     retorne 8.0 
    }
    retorne 12.0
  }
  funcao real calcularTroco(real total, real pago) {
    retorne pago - total
  }
  funcao vazio exibirCabecalho() {
    escreva("==============================", "\n")
    escreva("         AÇAÍ DO BIU          ", "\n")
    escreva("==============================", "\n")
  } 
  funcao vazio exibirRecibo(cadeia cliente, real subtotal, real frete, real total) {
    escreva("--- RECIBO: ", cliente, " ---", "\n")
    escreva("--- Subtotal: ", subtotal, " ---", "\n")
    escreva("--- Frete: ", frete, " ---", "\n")
    escreva("--- Total: ", total, " ---", "\n")
  }
  funcao inicio() {
    cadeia cliente
    inteiro quantidade, tamanho, adicionais
    real distacia, cupom, pago
    real subtotal, frete, total
    real copo = 0.0
    exibirCabecalho()

    escreva("Quantos pedidos? ", "\n")
    leia(quantidade)

    para(inteiro i = 1; i < quantidade; i++ ) {
      escreva("=== Pedido ", i, " ===", "\n")
      escreva("Cliente: ")
       leia(cliente)
      escreva("Tamanho do copo(300, 500 ou 70 ml): ")
       leia(tamanho)
      escreva("Quantidade de adicionais: ")
       leia(adicionais)
      escreva("Distacia da entrega(KM): ")
       leia(distacia)
      escreva("Cupom de desconto em % (0 se não tem desconto): ")
       leia(cupom)
      subtotal = aplicarDesconto(calcularPrecoCopo(tamanho, adicionais), copo)
      se(temFreteGratis(subtotal)) {
        frete = 0.0
      } senao {
        frete = calcularFrete(distacia)
      } 
      total = subtotal + frete
      exibirRecibo(cliente, subtotal, frete, total)
      escreva("Valor pago (PIX/DINHEIRO): ")
      leia(pago)
      se(pago >= total) {
        escreva("Troco R$: ", calcularTroco(total, pago), "\n")
      } senao {
        escreva("Pagamento insuficiente faltam R$ ", total - pago, "\n")
      }
    } 
  }
}
