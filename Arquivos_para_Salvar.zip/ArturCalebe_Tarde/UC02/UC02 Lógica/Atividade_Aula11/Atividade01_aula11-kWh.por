programa {
  funcao inicio() {
    real consumoEnergia, valorkWh, valorFinal
    const real  iluminacaoPublica = 50
    cadeia taxa
    
    
    escreva("Qual o consumo de energia elétrica em kWh? ", "\n")
    leia(consumoEnergia)
  
    escreva("Qual o valor cobrado por kWh? ", "\n")
    leia(valorkWh)
  
    escreva("A taxa da iluminação pública será cobrada? ", "\n")
    leia(taxa)
    
    valorFinal = consumoEnergia * valorkWh


    escolha(taxa){
    
    caso "sim":
   
      escreva("O valor da conta de energia será: ", valorFinal + iluminacaoPublica)
   
    pare

    caso "não":
    escreva("O valor da conta de energia será: ", valorFinal)
  
    pare

    caso  contrario:
      escreva("Opção Inválida")
    }
  }
}
