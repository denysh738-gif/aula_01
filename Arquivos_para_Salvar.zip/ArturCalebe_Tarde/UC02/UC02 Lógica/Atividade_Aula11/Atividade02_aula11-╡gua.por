programa {
  funcao inicio() {
    real consumoAgua, valorConsumo, valorFinal
    cadeia taxa
    const real taxaEsgoto = 20
    //Entrada de dados

      escreva("Qual o consumo de água em metros cúbicos? ", "\n")
        leia(consumoAgua)

      escreva("Qual o valor correspondente ao consumo? ", "\n")
        leia(valorConsumo)
      
      escreva("A cobraça da taxa de esgoto será adicionado ao valor final? ", "\n")
        leia(taxa)

    //processamento
        valorFinal = consumoAgua * valorConsumo 

    //Saída de dados

      escolha(taxa)
      {
        caso "Sim":
          escreva("O valor final da conta de água é: ", valorFinal + taxaEsgoto)
        pare

        caso "Não":
          escreva("O valor final da conta de água é: ", valorFinal)
        pare

        caso contrario:
          escreva("Cálculo Inválido")
      }  
  }
}
