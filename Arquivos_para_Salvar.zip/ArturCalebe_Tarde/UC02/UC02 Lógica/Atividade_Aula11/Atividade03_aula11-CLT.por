programa {
  funcao inicio() {
    //Declaração de variáveis
    real salarioMensal, quantidadeDeHoras, valorDaHoraTrabalhada, horasTrabalhadas, salarioFinal

    //Entrada de dados
    escreva("Qual o salário mensal do funcionário? ", "\n")
    leia(salarioMensal)
    escreva("Qual a quantidade de horas mensais? ", "\n")
    leia(quantidadeDeHoras)

    //Processamento de dados
    valorDaHoraTrabalhada = salarioMensal / quantidadeDeHoras
    escreva("O valor por hora trabalhada é: ",valorDaHoraTrabalhada, "\n")

    escreva("Quantas horas o funcionário trabalhou? ", "\n")
    leia(horasTrabalhadas)

    salarioFinal = valorDaHoraTrabalhada * horasTrabalhadas
    
    //Saída de dados
    escreva("O salário final do funcionário de acordo com as horas trabalhadas é: ", salarioFinal)
  }
}
