programa {
  funcao inicio() {
    //Cálculo imcompleto a partir do Imposto de renda, continuar de la para baixo
    //Declaração de variáveis
    real salarioBruto, parcelaADeduzir,aliquotaINSS,descontoINSS1,descontoINSS2,descontoINSS3,descontoINSS4, descontoImpostoDeRenda, aliquotaImpostoDeRenda
    caracter impostoDeRenda

    //Entrada de dados
    escreva("Qual o salário bruto do funcionário? ", "\n")
    leia(salarioBruto)
    
    se(salarioBruto <= 1621.00){
      aliquotaINSS = 0.075
      escreva("A alíquota será de 7,5%", "\n")
      descontoINSS1 = salarioBruto * aliquotaINSS
      escreva("O desconto do INSS é: ", descontoINSS1)
    } senao se(salarioBruto >= 1621.01 e salarioBruto <= 2902.84){
      aliquotaINSS = 0.09
      escreva("A aliquota será de 9% e a parcela a deduzir será de R$ 24,32", "\n")
      parcelaADeduzir = 24.32
      descontoINSS2 = (salarioBruto * aliquotaINSS) - parcelaADeduzir
      escreva("O desconto do INSS é: ", descontoINSS2)
    } senao se(salarioBruto >= 2902.85 e salarioBruto <= 4354.27){
      aliquotaINSS = 0.12
      escreva("A aliquota será de 12% e a parcela a deduzir será de R$ 111,40", "\n")
      parcelaADeduzir = 111.40
      descontoINSS3 = (salarioBruto * aliquotaINSS) - parcelaADeduzir
      escreva("O desconto do INSS é: ", descontoINSS3)
    } senao se(salarioBruto >= 4354.28 e salarioBruto <= 8475.55) {
      aliquotaINSS = 0.14
      escreva("A aliquota será de 14% e a parcela a deduzir será de R$ 198,49", "\n")
      parcelaADeduzir = 198.49
      descontoINSS4 = (salarioBruto * aliquotaINSS) - parcelaADeduzir
      escreva("O desconto do INSS é: ", descontoINSS4)
    } senao {
      escreva("Erro: Desconto do INSS não foi calculado!! ")
    }

    escreva("O Desconto do Imposto de Renda será aplicado? (S/N)")
    leia(impostoDeRenda)

    se(impostoDeRenda == 'S') {
      escreva("Então será aplicado o imposto de renda! ", "\n")
    }
      senao se(salarioBruto <= 2428.80){
      escreva("Imposto de renda isento! ", "\n")
    } 
    
    senao se(salarioBruto >= 2428.81 e salarioBruto <= 2826.65){
      aliquotaImpostoDeRenda = 0.075
      escreva("A aliquota será de 7,5% e a parcela a deduzir será de R$ 182,16", "\n")
      parcelaADeduzir = 182.16
      descontoImpostoDeRenda = (salarioBruto * aliquotaImpostoDeRenda) - parcelaADeduzir
      escreva("O desconto do INSS é: ", descontoImpostoDeRenda)
    } 
    
    senao se(salarioBruto >= 2902.85 e salarioBruto <= 4354.27){
      aliquotaImpostoDeRenda = 0.12
      escreva("A aliquota será de 12% e a parcela a deduzir será de R$ 111,40", "\n")
      parcelaADeduzir = 111.40
      descontoINSS3 = (salarioBruto * aliquotaImpostoDeRenda) - parcelaADeduzir
      escreva("O desconto do INSS é: ", descontoINSS3)
    } 
    
    senao se(salarioBruto >= 4354.28 e salarioBruto <= 8475.55) {
      aliquotaImpostoDeRenda = 0.14
      escreva("A aliquota será de 14% e a parcela a deduzir será de R$ 198,49", "\n")
      parcelaADeduzir = 198.49
      descontoINSS4 = (salarioBruto * aliquotaImpostoDeRenda) - parcelaADeduzir
      escreva("O desconto do INSS é: ", descontoINSS4)
    }




  }
}
