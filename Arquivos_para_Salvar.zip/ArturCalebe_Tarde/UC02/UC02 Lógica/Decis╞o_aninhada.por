programa {
  funcao inicio() {
    real valorCompra

    escreva("Informe o valor total da compra R$: ", "\n")
    leia(valorCompra)
   
    se(valorCompra >= 300.00) {
      escreva("Frete grátis: Compra acima de R$ 300.00")
    } senao se(valorCompra >= 150.0) {
      escreva("Frete: R$12.00")
    } senao se(valorCompra >= 80){
      escreva("Frete: R$20.00")
    } senao{
      escreva("Frete: R$35.00")
    }

    

    





  }
}
