programa {
  funcao inicio() {
    caracter temCupom
    real valorCompra

    escreva("Possui cupom de desconto? (S/N)", "\n")
    leia(temCupom)

    escreva("Informe o valor da compra: ", "\n")
    leia(valorCompra)
    se(temCupom == 'S'){
      se(valorCompra >= 100.0) {
        escreva("Cupom aplicado! Desconto de 10% concedido ", "\n")
      } senao{
        escreva("Cupom inválido! Compra deve ser acima de R$ 100.00")
      }
     } senao{
      escreva("Nenhum cupom informado, a compra seguirá sem desconto. ")
     }






  }
}
