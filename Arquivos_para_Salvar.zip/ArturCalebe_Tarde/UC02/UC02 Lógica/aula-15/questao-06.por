programa {
  funcao inicio() {
   /*
   Questão 06 -- Caça ao Erro
   Resposta:
   Um erro é que no caso 1 logo depois do escreva deveria ter um pare e não tem.
   E o outro erro é que no final deveria ter o caso contrario para se o caso for além do 4.

   */
   
   inteiro dia
      escreva("Digite o número do dia (1 a 7): ")
      leia(dia)
        escolha (dia)
        {
        caso 1:

        escreva("Domingo\n")
        caso 2:
        escreva("Segunda-feira\n")
        pare
        caso 3:
        escreva("Terça-feira\n")
        pare
        caso 4:
        escreva("Quarta-feira\n")
        pare
        caso 5:
        escreva("Quinta-feira\n")
        pare
        caso 6:
        escreva("Sexta-feira\n")
        pare
        caso 7:
        escreva("Sábado\n")
        pare
    } 
  }
}
