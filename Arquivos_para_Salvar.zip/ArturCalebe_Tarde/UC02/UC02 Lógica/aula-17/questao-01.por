programa {
  funcao inicio() {
    /*
    Questão 1 -- Linha de produção: Parametrizando o Relatório de Inspeção
    Resposta:
    Porque o turno age como se fosse a quantidade de números vão ficar nos colchetes, já as peças
    agem como se fosse as colunas, por isso elas tem que ser menor ou igual aos turnos, 
    e também para ficar com a estética de escada, se fosse fixo ficaria no modelo como os de cinema.
     
    */
    
    inteiro turno
    inteiro peca
    inteiro n
   
    escreva("Qual o número de turnos? ","\n")
    leia(n)
   
    para (turno = 1; turno <= n; turno++) {
      para (peca = 1; peca <= turno; peca++) {
        escreva("[", peca, "] ")
      }
    escreva("\n")
    }
  }
}
