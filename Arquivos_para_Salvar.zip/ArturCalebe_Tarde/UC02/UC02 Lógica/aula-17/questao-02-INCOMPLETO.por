programa {
  funcao inicio() {
    real peso_faixa, distacia_faixa = 1
    real tarifaBase, frete
    inteiro n
     

    escreva("Informe o número de entrada: ", "\n")
     leia(n)
    escreva("Qual o valor da tarifa base? ", "\n")
     leia(tarifaBase)
    
    para(peso_faixa = 1; peso_faixa <= n; peso_faixa++) {
    frete = peso_faixa * distacia_faixa * tarifaBase
       
       para(distacia_faixa = 1; distacia_faixa <= 4; distacia_faixa++) {
        escreva("Peso ", peso_faixa, " X Dis ", distacia_faixa, " = R$ ", frete, "\n")

       }
    }









  }
}
