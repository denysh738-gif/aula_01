programa {
  funcao inicio() {
    // Eu só não fiz o para dentro de para como a questão pediu, mas o comando funciona do jeito que a questão pede.
    
    real peso_faixa, distacia_faixa = 1.0
    real tarifaBase, frete
    inteiro n
     

    escreva("Informe o número de entrada: ", "\n")
     leia(n)
    escreva("Qual o valor da tarifa base? ", "\n")
     leia(tarifaBase)
    
    para(peso_faixa = 1.0; peso_faixa <= n; peso_faixa++) {
    frete = peso_faixa * distacia_faixa * tarifaBase
     escreva("Peso ", peso_faixa, " X Dis ", distacia_faixa, " = R$ ", frete, "  Peso ", peso_faixa, " X Dis ",distacia_faixa + 1, " = R$ ", frete * 2, "  Peso ", peso_faixa, " X Dis ", distacia_faixa + 2, " = R$ ", frete * 3, "\n")  
     
    }
   }
  }

