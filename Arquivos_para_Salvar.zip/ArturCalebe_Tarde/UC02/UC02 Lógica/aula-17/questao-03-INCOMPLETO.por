programa {
  funcao inicio() {
    real v, n, vendas, vendedores = 0.0
    real valorDasVendas, total, media

      escreva("Qual a quantidade de vendedores? ", "\n")
      leia(v)
      escreva("Qual a quantidade de vendas por vendedor? ", "\n")
      leia(n)  
    
      para(v = 1.0; v <= 1; v++) {
       escreva("-- Vendedor ", v, " --", "\n")
      para(vendas = 1.0; vendas <= n; vendas++ ) {
       escreva(" Venda ", vendas, ": ")
        leia(valorDasVendas)
      }
      para(valorDasVendas =  1.0; valorDasVendas <= 1; valorDasVendas++) {
       total = valorDasVendas
       media = total / n
       escreva("Total: ", total, " | Média: ", media)
      }  


    }
      
    
  
  }
}
