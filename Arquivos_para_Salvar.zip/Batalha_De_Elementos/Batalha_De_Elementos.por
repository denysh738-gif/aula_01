programa
{
	inclua biblioteca Graficos --> g
	inclua biblioteca Util --> u

	const inteiro LARGURA = 800
	const inteiro ALTURA = 500

	funcao inicio()
	{
		g.iniciar_modo_grafico(falso)
		g.definir_dimensoes_janela(LARGURA, ALTURA)
		g.definir_titulo_janela("Arena Elemental 2D")

		// Cores
		inteiro cor_fogo = g.criar_cor(230, 70, 40)
		inteiro cor_agua = g.criar_cor(40, 140, 230)
		inteiro cor_terra = g.criar_cor(110, 80, 40)
		inteiro cor_fundo = g.criar_cor(25, 25, 35)
		inteiro cor_chao = g.criar_cor(60, 60, 70)

		// Controle do jogo
		inteiro p1 = 0, p2 = 0
		inteiro hp_p1 = 100, hp_p2 = 100
		inteiro x_origem_p1 = 180, y_chao = 300
		inteiro x_origem_p2 = 560
		inteiro x_p1 = x_origem_p1, x_p2 = x_origem_p2

		// 1. ESCOLHA DO SEU GUERREIRO
		faca
		{
			renderizar_menu_selecao("ESCOLHA O SEU PERSONAGEM", cor_fogo, cor_agua, cor_terra, cor_fundo, cor_chao, y_chao)
			escreva("Digite o número do seu personagem (1-Fogo, 2-Água, 3-Terra): ")
			leia(p1)
		} enquanto (p1 < 1 ou p1 > 3)

		// 2. ESCOLHA DO OPONENTE
		faca
		{
			renderizar_menu_selecao("ESCOLHA O SEU OPONENTE", cor_fogo, cor_agua, cor_terra, cor_fundo, cor_chao, y_chao)
			escreva("Digite o número do oponente (1-Fogo, 2-Água, 3-Terra): ")
			leia(p2)
		} enquanto (p2 < 1 ou p2 > 3)

		// 3. LAÇO PRINCIPAL DE COMBATE
		inteiro golpe = 0
		enquanto (hp_p1 > 0 e hp_p2 > 0)
		{
			renderizar_cena_luta(x_p1, x_p2, y_chao, p1, p2, hp_p1, hp_p2, "Sua vez de atacar!", cor_fogo, cor_agua, cor_terra, cor_chao, cor_fundo)

			escreva("\nEscolha seu ataque -> [1] Combo de Mãos | [2] Combo de Pés: ")
			leia(golpe)

			se (golpe == 1 ou golpe == 2)
			{
				// --- ATAQUE DO JOGADOR ---
				// Animação: Avançar em direção ao inimigo
				enquanto (x_p1 < x_p2 - 60)
				{
					x_p1 = x_p1 + 20
					renderizar_cena_luta(x_p1, x_p2, y_chao, p1, p2, hp_p1, hp_p2, "Avançando...", cor_fogo, cor_agua, cor_terra, cor_chao, cor_fundo)
					u.aguarde(15)
				}

				// Cálculo do Dano
				inteiro dano_p1 = 0
				se (golpe == 1) { dano_p1 = u.sorteia(12, 20) }
				senao { dano_p1 = u.sorteia(18, 25) }
				hp_p2 = hp_p2 - dano_p1
				se (hp_p2 < 0) { hp_p2 = 0 }

				renderizar_cena_luta(x_p1, x_p2, y_chao, p1, p2, hp_p1, hp_p2, "GOLPE ATINGIDO!", cor_fogo, cor_agua, cor_terra, cor_chao, cor_fundo)
				u.aguarde(400)

				// Animação: Retornar à posição de origem
				enquanto (x_p1 > x_origem_p1)
				{
					x_p1 = x_p1 - 20
					renderizar_cena_luta(x_p1, x_p2, y_chao, p1, p2, hp_p1, hp_p2, "Retornando...", cor_fogo, cor_agua, cor_terra, cor_chao, cor_fundo)
					u.aguarde(15)
				}

				// --- ATAQUE DO OPONENTE ---
				se (hp_p2 > 0)
				{
					u.aguarde(300)
					inteiro golpe_cpu = u.sorteia(1, 2)

					// Animação: Oponente avança
					enquanto (x_p2 > x_p1 + 60)
					{
						x_p2 = x_p2 - 20
						renderizar_cena_luta(x_p1, x_p2, y_chao, p1, p2, hp_p1, hp_p2, "Oponente atacando!", cor_fogo, cor_agua, cor_terra, cor_chao, cor_fundo)
						u.aguarde(15)
					}

					inteiro dano_p2 = 0
					se (golpe_cpu == 1) { dano_p2 = u.sorteia(10, 18) }
					senao { dano_p2 = u.sorteia(16, 24) }
					hp_p1 = hp_p1 - dano_p2
					se (hp_p1 < 0) { hp_p1 = 0 }

					renderizar_cena_luta(x_p1, x_p2, y_chao, p1, p2, hp_p1, hp_p2, "VOCÊ FOI ATINGIDO!", cor_fogo, cor_agua, cor_terra, cor_chao, cor_fundo)
					u.aguarde(400)

					// Animação: Oponente retorna
					enquanto (x_p2 < x_origem_p2)
					{
						x_p2 = x_p2 + 20
						renderizar_cena_luta(x_p1, x_p2, y_chao, p1, p2, hp_p1, hp_p2, "Oponente retornando...", cor_fogo, cor_agua, cor_terra, cor_chao, cor_fundo)
						u.aguarde(15)
					}
				}
			}
		}

		// 4. TELA FINAL
		cadeia msg_fim = ""
		se (hp_p1 > 0) { msg_fim = "VITÓRIA!" }
		senao { msg_fim = "DERROTA!" }

		renderizar_cena_luta(x_p1, x_p2, y_chao, p1, p2, hp_p1, hp_p2, msg_fim, cor_fogo, cor_agua, cor_terra, cor_chao, cor_fundo)
		escreva("\nFim de Jogo! Resultado: ", msg_fim, "\n")
	}

	// Desenha a tela de seleção no canvas gráfico
	funcao renderizar_menu_selecao(cadeia titulo, inteiro c_fogo, inteiro c_agua, inteiro c_terra, inteiro c_fundo, inteiro c_chao, inteiro y_chao)
	{
		g.definir_cor(c_fundo)
		g.limpar()

		g.definir_cor(c_chao)
		g.desenhar_retangulo(0, y_chao + 90, LARGURA, 110, falso, verdadeiro)

		g.definir_cor(g.COR_BRANCO)
		g.definir_tamanho_texto(22)
		g.desenhar_texto(240, 50, titulo)

		g.definir_cor(c_fogo)
		g.definir_tamanho_texto(18)
		g.desenhar_texto(220, 160, "[ 1 ] - GUERREIRO DE FOGO")

		g.definir_cor(c_agua)
		g.desenhar_texto(220, 220, "[ 2 ] - GUERREIRO DE ÁGUA")

		g.definir_cor(c_terra)
		g.desenhar_texto(220, 280, "[ 3 ] - GUERREIRO DE TERRA")

		g.renderizar()
	}

	// Desenha o lutador com base na sua cor elemental
	funcao desenhar_boneco(inteiro x, inteiro y, inteiro tipo, inteiro c_fogo, inteiro c_agua, inteiro c_terra)
	{
		se (tipo == 1) { g.definir_cor(c_fogo) }
		senao se (tipo == 2) { g.definir_cor(c_agua) }
		senao { g.definir_cor(c_terra) }

		g.desenhar_elipse(x, y, 40, 40, verdadeiro) // Cabeça
		g.desenhar_retangulo(x + 5, y + 40, 30, 50, falso, verdadeiro) // Corpo
		g.desenhar_retangulo(x - 5, y + 45, 10, 30, falso, verdadeiro) // Braço esq.
		g.desenhar_retangulo(x + 35, y + 45, 10, 30, falso, verdadeiro) // Braço dir.
	}

	// Desenha a barra de vida proporcional ao HP
	funcao desenhar_barra_vida(inteiro x, inteiro y, inteiro hp, inteiro tipo, inteiro c_fogo, inteiro c_agua, inteiro c_terra)
	{
		g.definir_cor(g.COR_BRANCO)
		g.desenhar_retangulo(x, y, 254, 24, falso, falso)

		se (tipo == 1) { g.definir_cor(c_fogo) }
		senao se (tipo == 2) { g.definir_cor(c_agua) }
		senao { g.definir_cor(c_terra) }

		se (hp > 0)
		{
			g.desenhar_retangulo(x + 2, y + 2, hp * 2, 20, falso, verdadeiro)
		}
	}

	// Atualiza o quadro 2D da arena durante a batalha
	funcao renderizar_cena_luta(inteiro x1, inteiro x2, inteiro y, inteiro p1, inteiro p2, inteiro hp1, inteiro hp2, cadeia msg, inteiro c_fogo, inteiro c_agua, inteiro c_terra, inteiro c_chao, inteiro c_fundo)
	{
		g.definir_cor(c_fundo)
		g.limpar()

		g.definir_cor(c_chao)
		g.desenhar_retangulo(0, y + 90, LARGURA, 110, falso, verdadeiro)

		desenhar_barra_vida(50, 30, hp1, p1, c_fogo, c_agua, c_terra)
		desenhar_barra_vida(480, 30, hp2, p2, c_fogo, c_agua, c_terra)

		desenhar_boneco(x1, y, p1, c_fogo, c_agua, c_terra)
		desenhar_boneco(x2, y, p2, c_fogo, c_agua, c_terra)

		g.definir_cor(g.COR_AMARELO)
		g.definir_tamanho_texto(18)
		g.desenhar_texto(280, 110, msg)

		g.renderizar()
	}
}