programa {
  funcao inicio() {
    real peso1, kilo, pesoFinal

    escreva("Qual o limite de peso permitido pelo despacho?", "\n")
    leia(peso1)

    escreva("Quantos kilos pesava a mala de Carla?", "\n")
    leia(kilo)

    pesoFinal = peso1 - kilo

    escreva("Ainda restaria ", pesoFinal, " quilos antes de atingir o limite!!")
  }
}
