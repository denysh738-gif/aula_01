programa {
  funcao inicio() {
    real valor1, valor2, troco


   escreva("Qual o valor do passaporte de acesso?", "\n")
   leia(valor1)

   escreva("Qual o valor a mãe de Pedrinho deu a ele?", "\n")
   leia(valor2)

   troco = valor2 - valor1 

   escreva("O troco de Pedrinho após comprar o passaporte de acesso é: ", troco)

  }
}
