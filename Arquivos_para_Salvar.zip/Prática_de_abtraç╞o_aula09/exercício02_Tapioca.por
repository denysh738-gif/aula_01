programa {
  funcao inicio() {
    real fila, minutos, tempoFinal

    escreva("Quantas pessoas há na fila na frente de Sandra?", "\n")
    leia(fila)

    escreva("Quantas minutos Dona Maria leva para atender uma pessoa?", "\n")
    leia(minutos)
  
  tempoFinal = fila * minutos
  
  escreva("O tempo que Sandra terá que esperar até chegar a sua vez é: ", tempoFinal)
  }
}
