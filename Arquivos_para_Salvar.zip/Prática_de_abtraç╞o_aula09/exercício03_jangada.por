programa {
  funcao inicio() {
    real preco, amigos, valorFinal

    escreva("Qual o preço da passagem da jangada? ", "\n")
    leia(preco)

    escreva("Qual o numero de amigos que vão na jangada? ", "\n")
    leia(amigos)

    valorFinal = preco / amigos
    
    escreva("O valor a ser pago por cada amigo é: ", valorFinal)

  }
}
