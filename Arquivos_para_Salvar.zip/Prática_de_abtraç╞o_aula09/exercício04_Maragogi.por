programa {
  funcao inicio() {
    real km, kmLitro, litroFinal
     
    escreva("Quantos KM você vai percorrer? ", "\n")
    leia(km)

    escreva("Quantos KM o carro percorre com 1 litro? ", "\n")
    leia(kmLitro)

    litroFinal = km / kmLitro

    escreva("Ele precisará de ", litroFinal," para percorrer todo trajeto.")

  }
}
