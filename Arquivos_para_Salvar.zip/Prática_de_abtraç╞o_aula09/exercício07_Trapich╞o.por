programa {
  funcao inicio() {
    real gols, gols2, saldoFinal
     
     escreva("Quantos gols o CRB marcou ao final do campeonato? ", "\n")
     leia(gols)

     escreva("Quantos gols foram sofridos ao final do campeonato? ", "\n")
     leia(gols2)

     saldoFinal = gols - gols2

     escreva("Ao final do campeonato o time do CRB ficou com o saldo de gols de ", saldoFinal)
  }
}
