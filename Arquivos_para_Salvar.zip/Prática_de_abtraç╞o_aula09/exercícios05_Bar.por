programa {
  funcao inicio() {
    real preco, amigo, valorFinal

    escreva("Qual o preço final da compra? ", "\n")
    leia(preco)

    escreva("Quantos amigos estava no dia? ", "\n")
    leia(amigo)

   valorFinal = preco / amigo

    escreva("O valor final a ser dividido para cada amigo é: ", valorFinal)
  }
}
