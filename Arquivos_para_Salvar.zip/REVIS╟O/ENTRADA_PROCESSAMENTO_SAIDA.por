programa {
  funcao inicio() {
   real temperaturManha, temperaturaTarde
   // ENTRADA
   escreva("Informe a temperatura da manhã (°C)", "\n")
   leia(temperaturManha)
   escreva("Informe a temperatura da tarde (°C)", "\n")
   leia(temperaturaTarde)
   // PRECESSAMENTO
   real mediaTemp = (temperaturManha + temperaturaTarde) / 2
   // SAÍDA
   escreva("Média da temperatura no dia: ", mediaTemp, "\n")
  }
}
