programa {
  funcao inicio() {
    inteiro opcao
    inteiro pocoes = 1
    escreva("1- Atacar 2- Poção 3- Fugir: ")
    leia(opcao)
    escolha(opcao) {
      caso 1: 
        escreva("Você atacou o inimigo! ", "\n")
       pare
      caso 2:
        se(pocoes > 0) {
            pocoes = pocoes - 1
            escreva("Poção usada. Restam ", pocoes, "\n")
        } senao {
            escreva("Sem poções!", "\n")
        }
       pare
      caso 3:
        escreva("Você fugiu!", "\n")
       pare
      caso contrario: 
        escreva("Opção Inválida!", "\n")
    
    }
  }
}
/*
escreva("O laço de repetição PARA serve para quando sei a quantidade de vezes! ", "\n")
para(inteiro i = 1; i <= 5; i++) { //++; i = 1 + 1
   escreva(i, " ")
}
escreva("ENQUANTO se repete até a condição falhar! ", "\n")
inteiro contagem = 10
enquanto(contagem > 0) {
  escreva(contagem, " ")
  contagem = contagem - 1
}
escreva("FACA EMQUANTO repetir pelo menos uma vez")
inteiro tentativas = 10
faca {
    escreva("Faça: tentativas = ", tentativas, "\n")
} enquanto(tentativas < 5) {
     escreva("")
}


*/