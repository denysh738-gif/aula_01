programa {
  funcao inicio() {
    escreva("O laço de repetição PARA serve para quando sei a quantidade de vezes! ", "\n")
    para(inteiro i = 1; i <= 5; i++) { //++; i = 1 + 1
      escreva(i, " ")
    }
    escreva("\n","ENQUANTO se repete até a condição falhar! ", "\n")
    inteiro contagem = 10
    enquanto(contagem > 0) {
      escreva(contagem, " ")
      contagem = contagem - 1
    }
    escreva("\n","FACA EMQUANTO repetir pelo menos uma vez", "\n")
    inteiro tentativas = -10
    faca {
        escreva("Faça: tentativas = ", tentativas, "\n")
        tentativas = tentativas + 1
    } enquanto(tentativas < 5) 
  }
}
/*
inteiro pedidosPorDia[5] = {7, 4, 9, 6, 10} 
inteiro totalPorSemana = 0
para(inteiro i = 0; i < 5; i++) {
    escreva("Indice: ", i, " Valor armazenado: ", pedidosPorDia[i], "\n")
    totalPorSemana += pedidosPorDia[i]
}
escreva("Total por semana: ", totalPorSemana)














*/