programa {
  funcao inicio() {
    /**
     * Operadores aritméticos:
     * Soma (+): 2 + 2 
     * Subtração (-): 2 - 2
     * Multiplicação (*): 2 * 2
     * Divisão (/): 4 / 2
     * Môdulo (%): 3 % 2 = 1
     * 
     * Operadores relacionais:
     * Maio que (>): 3 > 2 = verdadeiro
     * Menor que (<): 2 < 7 = verdadeiro
     * Maior ou igual (>=): 5 >= 4 = verdadeiro
     * Menor ou igual (<=): 3 <= 7 = verdadeiro
     * Igual (==): 7 == 7 = verdadeiro
     * Diferente (!=): 6 != 7 = verdadeiro
     * 
     */
    inteiro cocos = 47
    escreva("2 + 3 * 4 = ", 2 + 3 * 4, "\n")
    escreva("(2 + 3 )* 4 = ", (2 + 3) * 4, "\n")
    escreva("47 >= 50? ", cocos >= 50)
    escreva("Par? ", cocos % 2 == 0, "\n") // falso

  }
}