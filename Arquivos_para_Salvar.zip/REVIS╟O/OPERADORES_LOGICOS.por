programa {
  funcao inicio() {
    /**
     * Operadores Lógicos:
     * E: Para que o E seja verdadeiro todas as condições tem que ser verdadeiros
     * OU: Para que o OU seja verdadeiro apenas uma condição tem que ser verdadeiro
     * NAO: Inverte o valor lógico, ou seja, se o valor for falso passa a ser verdadeiro e vice-versa
     *  */    
     logico chovendo = verdadeiro
     logico mareCheia = falso
     escreva("Chovendo E a mare está cheia? ", chovendo e mareCheia, "\n") //F
     escreva("Chovendo E a mare está cheia? ", chovendo ou mareCheia, "\n") //V
     escreva("Está chovendo? ", nao chovendo) //F
     escreva("Negação (chovendo e mareCheia) = ", nao(chovendo e mareCheia), "\n") //V
     escreva("Negação (chovendo e mareCheia) = ", nao(chovendo ou mareCheia), "\n") //F

  }
}
/*
inteiro idade
logico estudante
escreva("Informe a sua idade: ", "\n")
leia(idade)
se(idade >= 60) {
  escreva("Entrada gratuita! ", "\n")
} senao {
  escreva("Precisa pagar o ingresso! ","\n ")
}
escreva  


 */