programa {
  funcao inicio() {
    inteiro idade
    logico estudante
    escreva("Informe a sua idade: ", "\n")
    leia(idade)
    se(idade >= 60) {
      escreva("Entrada gratuita! ", "\n")
    } senao {
      escreva("Precisa pagar o ingresso! ","\n ")
    }
    estudante = verdadeiro
    se(estudante e idade < 18) {
      escreva("Meia-entrada especial!", "\n")
    }
  }
}
/*
 inteiro opcao
 inteio pocoes = 1
 escreva("1- Atacar 2- Poção 3- Fugir")
 leia(opcao)
 escolha(opcao) {
   caso 1: 
      escreva("Você atacou o inimigo! ", "\n")

   caso 2:
      se(pocoes > 0) {
          pocoes = pocoes - 1
          escreva("Poção usada. Restam ", pocoes)
      } senao {
          escreva("Sem poções!", "\n")
      }
 }




 */