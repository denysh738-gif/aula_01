programa {
  funcao inicio() {
    inteiro vendas[3][3] = {
            {7, 5, 9},
            {4, 8, 6},
            {10, 3, 7}
    }
    inteiro contadorLinhas
    para(inteiro linha = 0; linha < 3; linha++) {
        contadorLinhas = 0
        escreva("Linha no Índice: ", linha, "\n")
        para(inteiro coluna = 0; coluna < 3; coluna++) {
          escreva("Valor no encontro da linha: ", linha, " e da coluna: ", coluna, " = ", vendas[linha][coluna], "\n")
          contadorLinhas += vendas[linha][coluna]
        }
        escreva("Total geral: ", contadorLinhas, "\n")
    }
    escreva("\n")
    inteiro contadorColuna
    para(inteiro coluna = 0; coluna < 3; coluna++) {
        contadorColuna = 0
        escreva("Linha no Índice: ", coluna, "\n")
        para(inteiro linha = 0; linha < 3; linha++) {
          escreva("Valor no encontro da linha: ", linha, " e da coluna: ", coluna, " = ", vendas[linha][coluna], "\n")
          contadorColuna += vendas[linha][coluna]
        }
        escreva("Total geral: ", contadorColuna, "\n")
    }
  }
}
/*
funcao vazio saudarEquipe(cadeia nomeEquipe) {
   escreva("Olá ", nomeEquipe)
}
funcao









*/ 