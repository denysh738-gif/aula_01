programa {
  funcao inicio() {
    const real PRECO_COCO = 5.0
    cadeia cliente = "Rita"
    inteiro cocos = 5
    logico pagou = falso
  //caracter, exemplo: sexo = "M"
  //vazio, exemplo: funcao vazio escreva2()()
    escreva(cliente, " levou ", cocos, " cocos", "\n")
    real total = cocos * PRECO_COCO 
    escreva("Total R$: ", total, "\n") 
    pagou = verdadeiro
    
  }

}
