programa {
  funcao inicio() {
    inteiro pedidosPorDia[5] = {7, 4, 9, 6, 10} 
    inteiro totalPorSemana = 0
    para(inteiro i = 0; i < 5; i++) {
        escreva("Indice: ", i, " Valor armazenado: ", pedidosPorDia[i], "\n")
        totalPorSemana += pedidosPorDia[i]
    }
    escreva("Total por semana: ", totalPorSemana)


  }
}
/*






*/