# **Documentação - SA03-grupo-07 (incompleto)**



## **1. Sobre o sistema**

Nosso sistema foi desenvolvido com o propósito de ajudar o financeiro da empresa TáNaMão Delivery. Seu setor financeiro faz seu fechamento toda Segunda-feira, escrito à mão, porém houve erro de conta e o pagamento atrasou. Este protótipo registra: pagamento por entrega (ganho do entregador é total de entregas vezes o valor do pagamento), bônus de meta (se maior ou igual, recebe um bônus), cancelamentos (se a culpa for do entregador, há um desconto de valor fixo), a situação do entregador na semana (destaque, regular e atenção, nesta ordem), relatório da base (total a pagar, total de entregas da semana, quantos entregadores há em cada situação, quem teve o maior repasse e dia mais movimentado) e a consulta de extrato (ao digitar o código do entregador, é possível ver seu número de entregas, total de cancelamentos e a situação).



2\. Código de autenticidade do grupo

SA03S-G07-4DAB



## **3. Integrantes e papéis**



|**Integrante (nome completo)**|**Papel**|**Artefato entregue**|
|-|-|-|
|Raynne Souza Joventino|EPS|docs/EPS modelo.md|
|Rayane Ester de Lima Silva e Flaviane Maria da Silva Oliveira|Fluxograma|docs/Diagrama TRABALHO.draw.io.png|
|Artur Calebe Silva do Nascimento|Código|4-codigo-modelo.por|
|Flaviane Maria da Silva Oliveira|Teste de mesa|docs/teste de mesa.md|

|Bruno Bezerra de Lima|Documentação|README.md|
|-|-|-|



## **4. Como executar o programa**



1\. Acesse o Portugol Web Studio: https://portugol.dev/

2\.

3\.



## **5. Estrutura do repositório**



uc02-sa03-grupo07

|---README.md

|---docs/

|   |---

|   |---Diagrama TRABALHO.draw.io.png

|   |---<fluxograma da decisão>

|   +---teste de mesa.md

+---src/

&#x20;   +---.por



## **6. Estruturas de dados escolhidas e por quê**



|**Estrutura**|**Onde foi usada**|**Por que essa escolha**|
|-|-|-|
|Registro|Não utilizado|Não utilizado|
|Vetor|Usada para armazenar dados das entregas|Porque foi utilizado para armazenar quantas entregas cada entregador fez e para armazenar quantas entregas teve por dia.|
|Matriz|Usada para armazenar as entregas do dia.|Para calcular o valor bruto da semana.|



## **7. Módulos do programa**



|**Módulo**|**Tipo (função ou procedimento)**|**O que faz**|**Parâmetros**|**Retorno**|
|-|-|-|-|-|
|Não utilizado|-|-|-|-|
|Não utilizado|-|-|-|-|



## **8. Decisões do grupo**



Dúvida: não houve dúvidas.

Decisão: -

Motivo: -



## **9. Saída real da execução**



\[SA03S-G07-4DAB]

\--- Relatório da Base ---

Base: Gruta de Lourdes



Código: 201 | Nome: Igor  

Entregas feitas na semana: 47

Valor bruto semanal: 282

O entregador Igor não conseguiu o bônus da meta semanal!

Cancelamentos: 2

Valor liquído: R$ 262



Código: 202 | Nome: Cleiton  

Entregas feitas na semana: 52

Valor bruto semanal: 312

O entregador Cleiton conseguiu o bônus da meta semanal! Bônus de R$ 70,00

Cancelamentos: 2

Valor liquído: R$ 362



Código: 203 | Nome: Wesley

Entregas feitas na semana: 61

Valor bruto semanal: 366

O entregador Wesley conseguiu o bônus da meta semanal! Bônus de R$ 70,00

Cancelamentos: 0

Valor liquído: R$ 436



Código: 204 | Nome: Mirela

Entregas feitas na semana: 23

Valor bruto semanal: 138

A entregadora Mirela não conseguiu o bônus da meta semanal!

Cancelamentos: 0

Valor liquído: R$ 138



O total a pagar será: 1198

Entregas totais da semana: 183

Em destaque: 1

Em regular: 2

Em atenção: 1

Maior Repasse: Wesley

O dia mais movimentado foi quinta com 40



Qual o código do entregador?(para finalizar digite 0)

203

Código: 203 | Nome: Wesley  

Entregas feitas na semana: 61

Valor bruto semanal: 436

O entregador Wesley conseguiu o bônus da meta semanal! Bônus de R$ 70,00

Cancelamentos: 0

Valor liquído: 506.0

Situação: Destaque!



Qual o código do entregador?(para finalizar digite 0)

0



SA03S-G07-4DAB



## **10. Teste de mesa**



O arquivo do teste de mesa encontra-se na pasta docs/, o nome do arquivo é: 



## **11. Declaração de autoria**



Declaramos que este trabalho foi desenvolvido integralmente pelos integrantes

do grupo, sem uso de inteligência artificial e sem cópia de código de outros

grupos ou da internet.



Integrante 1: Bruno Bezerra de Lima - papel: documentação e

Integrante 2: Artur Calleb - papel: código

Integrante 3: Flaviane Maria da Silva Oliveira - papel: teste de mesa

Integrante 4: Rayane Ester de Lima Silva - papel: fluxogramas

Integrante 5: Raynne Souza Joventino - EPS

Código de autenticidade do grupo: SA03S-G07-4DAB

