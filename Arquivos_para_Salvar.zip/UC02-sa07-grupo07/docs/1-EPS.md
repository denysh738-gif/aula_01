# Diagrama EPS — Fechamento semanal de entregas · Grupo 07

> **MODELO DE REFERÊNCIA.** O que está preenchido vem do **cartão do grupo**. O que está como `______` é com vocês.
> Preencham **antes** de abrir o Portugol (roteiro de trabalho, passo 2). Copie este arquivo para `docs/` e escreva com as suas palavras.

**Sistema:** TáNaMão Delivery — fechamento semanal · **Base:** Gruta de Lourdes
**Código de autenticidade:** `SA03S-G07-4DAB`
**Responsável pelo EPS:** Raynne Souza  ·  **Integrantes:** ______________________________

---

## E — ENTRADA (o que o programa recebe)

### E1. Parâmetros da base (valores fixos do cartão)

| Dado | Valor do cartão | Tipo de dado (`inteiro`, `real` ou `cadeia`) |
|---|---|---|
| Pagamento por entrega | R$ 6,00 | real |
| Meta semanal de entregas | 50 | inteiro |
| Meta mínima da semana | 40 | inteiro |
| Valor do bônus de meta | R$ 70,00 | real |
| Desconto por cancelamento | R$ 10,00 | real |
| Nome da base | Gruta de Lourdes | cadeia |
| Código de autenticidade | SA03S-G07-4DAB | cadeia |

### E2. Cadastro dos entregadores (valores do cartão)

| Código | Nome | Cancelamentos | Tipo do código | Tipo do nome | Tipo dos cancelamentos |
|---|---|---|---|---|---|
| 201 | Igor | 2 | inteiro | cadeia | inteiro |
| 202 | Cleiton | 2 | inteiro | cadeia | inteiro |
| 203 | Wesley | 0 | inteiro | cadeia | inteiro |
| 204 | Mirela | 0 | inteiro | cadeia | inteiro |

### E3. Entregas concluídas por dia (valores do cartão)

| Código | Segunda | Terça | Quarta | Quinta | Sexta |
|---|---|---|---|---|---|
| 201 | 7 | 10 | 9 | 10 | 11 |
| 202 | 8 | 10 | 7 | 14 | 13 |
| 203 | 14 | 10 | 18 | 11 | 8 |
| 204 | 6 | 2 | 6 | 4 | 5 |

Estrutura de dados que guarda esta tabela: matriz (linhas = 4 · colunas = 5)

### E4. Entrada pelo teclado

| O que o operador digita | Tipo | Quando a digitação termina |
|---|---|---|
| codigo | __inteiro_ | ______0______ |

---

## P — PROCESSAMENTO (o que o programa calcula e decide)

Escreva cada passo como uma **conta ou condição**, em português, usando os valores do cartão quando precisar.
Os números entre parênteses são as **regras do enunciado** (seção 2) que vocês devem ler. 

| # | Passo | Como é feito (conta, condição ou repetição) |
|---|---|---|
| P1 | Total de entregas de cada entregador | 47, 52, 61, 23 |
| P2 | Ganho com as entregas (regra 1) | |
| P3 | Bônus de meta (regra 2) | 70 reais |
| P4 | Desconto por cancelamentos (regra 3) | 10 reais_ |
| P5 | Repasse da semana (regra 4) | 1198  |
| P6 | Situação do entregador, na ordem do enunciado (regra 5) | 1º Regular· 2ºregular· 3º Destaque  . 4º Atenção |
| P7 | Total a pagar da base (regra 6) |  |
| P8 | Total de entregas da semana (regra 6) | ______________________________ |
| P9 | Quantos entregadores em cada situação (regra 6) | ______________________________ |
| P10 | Quem teve o maior repasse (regra 6) | ______________________________ |
| P11 | Dia mais movimentado, somando todos (regra 6) | ______________________________ |
| P12 | Consulta de extrato: busca pelo código e repetição (regra 7) | ______________________________ |

**Repetições usadas (quais laços, percorrendo o quê):** ______________________________

**Acumuladores e contadores (nome e para que servem):** ______________________________

---

## S — SAÍDA (o que o programa mostra)

A **primeira linha** impressa é o código de autenticidade do grupo. Complete de onde vem cada informação (variável ou passo P1–P12).

| Informação exibida | Vem de (passo ou variável) |
|---|---|
| Código de autenticidade (1ª linha) | `SA03S-G07-4DAB` |
| Nome da base | Gruta de Lourdes |
| Por entregador: código, nome, total de entregas, cancelamentos, ganho, bônus, desconto, repasse e situação | ______________________ |
| Total a pagar | ______________________ |
| Total de entregas da semana | ______________________ |
| Quantidade de entregadores por situação | ______________________ |
| Entregador com o maior repasse | ______________________ |
| Dia mais movimentado | ______________________ |
| Extrato do entregador consultado (dia a dia, total, cancelamentos e situação) | ______________________ |
| Aviso quando o código não existe | ______________________ |

---

## Para discutir em grupo antes de codar

1. O que acontece com um entregador que tem **exatamente** o número de entregas da meta? Confiram no seu cartão se alguém está nessa situação. Resposta do grupo: ______________
2. Em que situação alguém recebe o bônus e **não** é DESTAQUE? Resposta do grupo: ______________
3. Alguma regra deu margem a dúvida? Anotem aqui (vai para a seção 8 da documentação): ______________

