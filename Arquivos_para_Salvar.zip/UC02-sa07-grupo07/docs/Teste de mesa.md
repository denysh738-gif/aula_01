









***TESTE DE MESA:***





|***Passo***|***Linha***|***Código***|***Condição***|***Ação realizada***|***Saída***|-|
|-|-|-|-|-|-|-|
|**1**|**142**|**-**|**-**|**lê o código**|**Qual o código do entregador?**|-|
|**2**|**143**|**201**|**-**|**Entra no enquanto**|**-**|-|
|**3**|**146**|**201**|**201 diferente de 0: verdadeiro**|**Localiza Igor**|**-**|-|
|**4**|**147**|**201**|**201 = 201: verdadeiro**|**Exibe o nome**|**Código:201\|Nome: Igor**|-|
|**5**|**148**|**201**|**-**|**Soma as entregas**|**Entrega na semana: 47**|-|
|**6**|**152**|**201**|**-**|**Calcula o valor bruto**|**Valor bruto: R$282,00**|-|
|**7**|**154**|**201**|**-**|**Calcula o valor líquido**|**valor líquido: R$262,00**|-|
|**8**|**196**|**-**|**-**|**Lê outro código**|**Qual o código do entregador?**|-|
|**9**|**143**|**209**|**209 diferente de 0: verdadeiro**|**Entra no enquanto**|**-**|-|
|**10**|**192**|**209**|**Código inexistente**|**Executa o senao**|**-**|-|
|**11**|**193**|**209**|**-**|**Exibe mensagem de erro**|**O código não existe**|-|
|**12**|**196**|**-**|**-**|**Lê outro código**|**Qual o código do entregador?**|-|
|**13**|**143**|**0**|**0 diferente de 0: falso**|**Sai do enquanto**|**-**|-|
|**14**|**200**|**0**|**-**|**Finaliza o programa**|**Fim**|-|
|**Nome**|**Código**|**Entrega**|**Valor Bruto**|**Bônus**|**Desconto**|***Valor liquido***|
|**Igor**|**201**|**47**|**R$ 282,00**|**R$0,00**|**R$20,00**|***R$262,00***|



