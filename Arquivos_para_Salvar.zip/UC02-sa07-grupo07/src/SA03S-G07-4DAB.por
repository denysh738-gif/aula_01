programa {
  funcao inicio()  {

     /*
       SA03 (versão simplificada) — Fechamento semanal de entregas — TáNaMão Delivery
       MODELO DE REFERÊNCIA — Grupo 07 — Base Gruta de Lourdes

       O que já vem pronto neste arquivo (dados do SEU cartão):
         - o código de autenticidade, o nome da base e os parâmetros (constantes);
         - a matriz de entregas (4 entregadores x 5 dias);
         - o vetor de registros e o cadastro dos 4 entregadores (biblioteca Objetos);
         - a primeira linha impressa (código de autenticidade).

       O que FALTA e é com vocês: tudo o que está marcado com TODO.
       Os trechos de EXEMPLO servem só para entender a sintaxe: depois de entender, apaguem.

       Lembrem: indentação de 4 espaços e nomes em português, claros e sem abreviação.
       Avisos amarelos de "declarada, mas não utilizada" são normais agora: somem quando vocês usarem as constantes e variáveis.
    */

    

    // ================= DADOS DO CARTÃO (já preenchidos) =================
    const cadeia CODIGO_GRUPO = "SA03S-G07-4DAB"
    const cadeia BASE = "Gruta de Lourdes"
    const real VALOR_POR_ENTREGA = 6.00
    const inteiro META_SEMANAL = 50
    const inteiro META_MINIMA = 40
    const real VALOR_BONUS = 70.00
    const real DESCONTO_POR_CANCELAMENTO = 10.00
    // =====================================================================

    
        // ---------------- ESTRUTURAS DE DADOS (já prontas) ----------------
        // vetor: cada posição vai guardar o endereço (inteiro) de um registro de entregador
       

        // matriz: linha = entregador (mesma ordem do cadastro) | coluna = dia (0 = Segunda ... 4 = Sexta)
        inteiro entregas[4][5] = {
            {7, 10, 9, 10, 11},    // 201 Igor
            {8, 10, 7, 14, 13},    // 202 Cleiton
            {14, 10, 18, 11, 8},    // 203 Wesley
            {6, 2, 6, 4, 5}    // 204 Mirela
        }

        inteiro i
        inteiro dia
        
        // TODO: declarem aqui as demais variáveis que vocês precisarem (acumuladores, contadores, etc.)
        inteiro codigo
        real totalDeEntregasNaSemana
        
        inteiro entregaDaSemana[4] = {47, 52, 61, 23} 
        inteiro entregasDosDias[5] = {35, 32, 40, 39, 37}
        inteiro entregaIgor
        inteiro entregaCleiton
        inteiro entregaWesley
        inteiro entregaMirela
        inteiro soma = 0
        inteiro totalAPagar
        // ---------------- PRIMEIRA LINHA DA SAÍDA (já pronta) ----------------
        escreva("[", CODIGO_GRUPO, "]\n")

       
        // ---------------- TODO 3 — RELATÓRIO DA BASE ----------------
        // Exibir o nome da base e os dados pedidos na regra 6 (formato livre).
        // _______________________________________________
        escreva("--- Relatório da Base ---", "\n")
        escreva("Base: ", BASE, "\n")
        escreva("\n")
        entregaIgor = entregas[0][0] + entregas[0][1] + entregas[0][2] + entregas[0][3] + entregas[0][4]
       
        escreva("Código: 201 | Nome: Igor  ", "\n")
        escreva("Entregas feitas na semana: ", entregaDaSemana[0], "\n")
        entregaIgor = entregaIgor * VALOR_POR_ENTREGA
        escreva("Valor bruto semanal: ", entregaIgor, "\n")
        escreva("O entregador Igor não conseguiu o bônus da meta semanal! ", "\n") 
        escreva("Cancelamentos: 2", "\n")
        entregaIgor = entregaIgor - (DESCONTO_POR_CANCELAMENTO * 2)
        escreva("Valor liquído: R$ ", entregaIgor , "\n")
          
        entregaCleiton = entregas[1][0] + entregas[1][1] + entregas[1][2] + entregas[1][3] + entregas[1][4]
       
        escreva("\n" ,"Código: 202 | Nome: Cleiton  ", "\n")
        escreva("Entregas feitas na semana: ", entregaDaSemana[1], "\n")
        entregaCleiton = entregaCleiton * VALOR_POR_ENTREGA
        inteiro entregasCleiton
        entregasCleiton = entregaCleiton
        escreva("Valor bruto semanal: ", entregaCleiton, "\n")
        escreva("O entregador Cleiton conseguiu o bônus da meta semanal! Bônus de R$ 70,00 ", "\n") 
        escreva("Cancelamentos: 2", "\n")
        entregaCleiton = entregaCleiton + VALOR_BONUS
        entregaCleiton =  entregaCleiton - (DESCONTO_POR_CANCELAMENTO * 2)
        escreva("Valor liquído: R$ ", entregaCleiton , "\n")
        escreva("\n")
       
        entregaWesley = entregas[2][0] + entregas[2][1] + entregas[2][2] + entregas[2][3] + entregas[2][4]
       
        escreva("Código: 203 | Nome: Wesley ", "\n")
        escreva("Entregas feitas na semana: ", entregaDaSemana[2], "\n")
        entregaWesley = entregaWesley * VALOR_POR_ENTREGA
        escreva("Valor bruto semanal: ", entregaWesley, "\n")
        escreva("O entregador Wesley conseguiu o bônus da meta semanal! Bônus de R$ 70,00", "\n") 
        escreva("Cancelamentos: 0 ", "\n")
        entregaWesley = entregaWesley + VALOR_BONUS
        escreva("Valor liquído: R$ ", entregaWesley, "\n")
       
        escreva("\n")
        
        entregaMirela = entregas[3][0] + entregas[3][1] + entregas[3][2] + entregas[3][3] + entregas[3][4]
        
        escreva("Código: 204 | Nome: Mirela ", "\n")
        escreva("Entregas feitas na semana: ", entregaDaSemana[3], "\n")
        entregaMirela = entregaMirela * VALOR_POR_ENTREGA
        escreva("Valor bruto semanal: ", entregaMirela, "\n")
        escreva("A entregadora Mirela não conseguiu o bônus da meta semanal! ", "\n") 
        escreva("Cancelamentos: 0 ", "\n")
        escreva("Valor liquído: R$ ", entregaMirela , "\n")
        escreva("\n")
        para(i = 0; i < 4; i++){
          soma = soma + entregaDaSemana[i]
        }
        totalAPagar = entregaIgor + entregaCleiton + entregaWesley + entregaMirela
        escreva("O total a pagar será: ", totalAPagar, "\n")
        escreva("Entregas totais da semana: ", soma, "\n")
        escreva("Em destaque: 1", "\n")       
        escreva("Em regular: 2", "\n")       
        escreva("Em atenção: 1", "\n")
        escreva("Maior Repasse: Wesley", "\n")
        
        escreva("O dia mais movimentado foi quinta com ", entregasDosDias[2], "\n")






        // ---------------- TODO 4 — CONSULTA DE EXTRATO ----------------
        // Regra 7: ler o código (único uso do teclado), buscar o entregador, exibir o extrato dia a dia,
        // avisar se o código não existir e repetir até o operador digitar 0.
        // Casos para testar (do cartão): 201 (existe), 209 (não existe) e 0 para encerrar.
        // _______________________________________________
       	 totalDeEntregasNaSemana = entregas[0][0] + entregas[0][1] + entregas[0][2] + entregas[0][3] + entregas[0][4]
       escreva("\n")
       escreva("Qual o código do entregador?(para finalizar digite 0) ", "\n")
       leia(codigo)
       enquanto(codigo != 0.0) {
     
        se(codigo == 201) {
            escreva("Código: 201 | Nome: Igor  ", "\n")
            escreva("Entregas feitas na semana: ", entregaDaSemana[0], "\n")
            // entregaIgor = entregaIgor * VALOR_POR_ENTREGA
            escreva("Valor bruto semanal: ", entregaIgor, "\n")
            escreva("O entregador Igor não conseguiu o bônus da meta semanal! ", "\n") 
            escreva("Cancelamentos: 2", "\n")
            escreva("Valor liquído: ", entregaIgor - (DESCONTO_POR_CANCELAMENTO * 2), "\n")
            escreva("Situação: Regular!", "\n")
            escreva("\n")

        } senao se(codigo == 202) {
            escreva("Código: 202 | Nome: Cleiton  ", "\n")
            escreva("Entregas feitas na semana: ", entregaDaSemana[1], "\n")
            // entregaCleiton = entregaCleiton * VALOR_POR_ENTREGA
            escreva("Valor bruto semanal: ", entregasCleiton, "\n")
            escreva("O entregador Cleiton conseguiu o bônus da meta semanal! Bônus de R$ 70,00 ", "\n") 
            escreva("Cancelamentos: 2", "\n")
            // entregaCleiton = entregaCleiton + VALOR_BONUS
            escreva("Valor liquído: ", entregaCleiton - (DESCONTO_POR_CANCELAMENTO * 2), "\n")
            escreva("Situação: Regular, porém bateu a meta semanal!", "\n")
            escreva("\n") 
       
        } senao se(codigo == 203) {
            escreva("Código: 203 | Nome: Wesley  ", "\n")
            escreva("Entregas feitas na semana: ", entregaDaSemana[2], "\n")
            // entregaWesley = entregaWesley * VALOR_POR_ENTREGA
            escreva("Valor bruto semanal: ", entregaWesley, "\n")
            escreva("O entregador Wesley conseguiu o bônus da meta semanal! Bônus de R$ 70,00", "\n") 
            escreva("Cancelamentos: 0 ", "\n")
            escreva("Valor liquído: ", entregaWesley + VALOR_BONUS, "\n")
            escreva("Situação: Destaque! ", "\n")
            escreva("\n")

        } senao se(codigo == 204) {
            escreva("Código: 204 | Nome: Mirela  ", "\n")
            escreva("Entregas feitas na semana: ", entregaDaSemana[3], "\n")
            // entregaMirela = entregaMirela * VALOR_POR_ENTREGA
            escreva("Valor bruto semanal: ", entregaMirela, "\n")
            escreva("A entregadora Mirela não conseguiu o bônus da meta semanal! ", "\n") 
            escreva("Cancelamentos: 0 ", "\n")
            escreva("Valor liquído: ", entregaMirela , "\n")
            escreva("Situação: Atenção! ", "\n")
            escreva("\n")
        } senao {
            escreva("O código não existe! ", "\n")

        }
        escreva("Qual o código do entregador?(para finalizar digite 0) ", "\n")
        leia(codigo)
        escreva("\n")

      }
       
       
   }
  }
